package com.capgemini.chess.dataaccess.enums;

public enum ChallengeStatus {
	WAITING_FOR_REPLY,
	ACCEPTED,
	DECLINED;
}
